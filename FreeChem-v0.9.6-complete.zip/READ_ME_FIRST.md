﻿# FreeChem v0.9.6 完整本地包

下载解压后可直接部署到游戏，也可修改源码重新构建。

## 目录
- `FreeChem/`：模组成品（含 `FreeChem.dll`），可直接复制到 `Probably Stolen\Mods\`
- `src/`：C# 源码与 `FreeChem.csproj`
- `tools/`：生成器、静态验收、逻辑自检、C# harness、只读 API 探针源码
- `docs/`：设计/进度/审查/研究文档
- `build.ps1`：构建脚本（需要 .NET SDK 8；若存在 `.dotnet\dotnet.exe` 会自动使用）
- `install.ps1`：部署脚本（自动备份原有 Mods\FreeChem）

## 直接部署（不改代码）
```powershell
.\install.ps1 -GameDir "D:\SteamLibrary\steamapps\common\Probably Stolen"
```
或手动把 `FreeChem/` 复制到 `...\Probably Stolen\Mods\FreeChem\`，然后启动游戏。

## 修改后构建
```powershell
.\build.ps1 -GameDir "D:\SteamLibrary\steamapps\common\Probably Stolen"
.\install.ps1 -GameDir "D:\SteamLibrary\steamapps\common\Probably Stolen"
```
构建依赖游戏目录下的 `Assembly-CSharp.dll`、UnityEngine 等程序集（脚本通过 `-p:GameDir=` 传入），不需要把游戏 DLL 放进本包。

## 验证（可选）
```powershell
python tools/validate.py
python tools/logic_check.py
cd tools/logic-harness; dotnet run
```

## 未包含
- `.dotnet/`（本地 SDK，约 700MB；请自装 .NET SDK 8 或把 `.dotnet` 放回根目录）
- `ref-modding/`（第三方指南副本）
- `tools/api-probe/out*/`（游戏程序集导出的 IL 数据；可用 `run.ps1` 自行生成）
- `bin/obj/__pycache__/日志/临时文件`

## 注意
- 仓库/包未附 LICENSE，如需开源请自行添加。
- 未实机验证项见 `HANDOFF.md`。
