﻿param([string]$GameDir = "D:\SteamLibrary\steamapps\common\Probably Stolen")
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$dotnet = Join-Path $root ".dotnet\dotnet.exe"
if (!(Test-Path $dotnet)) { $dotnet = "dotnet" }
Push-Location (Join-Path $root "src")
& $dotnet build FreeChem.csproj -c Release "-p:GameDir=$GameDir\"
Pop-Location
$built = Join-Path $root "src\bin\Release\netstandard2.1\FreeChem.dll"
if (Test-Path $built) {
  Copy-Item $built (Join-Path $root "FreeChem\FreeChem.dll") -Force
  Copy-Item $built (Join-Path $PSScriptRoot "FreeChem\FreeChem.dll") -Force
  Write-Host "Build OK: $built"
} else { throw "Build output not found: $built" }
