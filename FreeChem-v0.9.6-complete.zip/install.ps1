﻿param([string]$GameDir = "D:\SteamLibrary\steamapps\common\Probably Stolen")
$ErrorActionPreference = "Stop"
$modSrc = Join-Path $PSScriptRoot "FreeChem"
$modDst = Join-Path $GameDir "Mods\FreeChem"
if (!(Test-Path (Join-Path $GameDir "Probably Stolen.exe"))) { throw "GameDir 不正确：$GameDir" }
if (Test-Path $modDst) { Rename-Item $modDst ($modDst + ".bak_" + (Get-Date -Format "yyyyMMdd_HHmmss")) }
Copy-Item $modSrc $modDst -Recurse -Force
Write-Host "Installed FreeChem to: $modDst"
