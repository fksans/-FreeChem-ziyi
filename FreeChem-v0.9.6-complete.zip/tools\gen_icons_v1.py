# -*- coding: utf-8 -*-
"""
FreeChem 像素图标生成器
按 Probably Stolen 官方规范：Textures/Items/*.png，透明背景，
不透明像素决定物品在背包中的占格形状（SetSpriteAndShapeFromMod）。
统一 32x32 单格像素画，深色描边 + 状态配色：
  固体 = 琥珀/晶体色 + 棱角颗粒
  液体 = 瓶内液面 + 波纹高光
  气体 = 耐压气罐 + 飘散气泡
"""
from PIL import Image, ImageDraw, ImageFont
import os

S = 32
OUT = r"C:\Users\Administrator\WorkBuddy\Claw\ps-chem-mod\FreeChem\Textures\Items"
SHEET = r"C:\Users\Administrator\WorkBuddy\Claw\ps-chem-mod\icon_sheet.png"
os.makedirs(OUT, exist_ok=True)

# ---------- 调色板 ----------
INK      = (22, 26, 36)
INK2     = (52, 60, 78)
METAL    = (152, 162, 178)
METAL_D  = (96, 106, 124)
METAL_HI = (214, 224, 236)
GLASS    = (196, 222, 232)
GLASS_HI = (238, 250, 255)
WHITE    = (236, 242, 248)
CORK     = (158, 116, 72)
SOLID    = (216, 170, 96)
SOLID_D  = (158, 114, 58)
CRYSTAL  = (138, 204, 236)
CRYSTAL_D= (78, 140, 186)
GAS      = (196, 186, 232)
GAS_D    = (136, 124, 184)
RED      = (214, 86, 78)
YELLOW   = (232, 198, 88)
GREEN    = (96, 190, 120)
ACID     = (126, 196, 96)
BASE     = (104, 148, 226)
WATER    = (116, 204, 214)
OIL      = (178, 132, 72)
SOLUTION = (168, 120, 200)
FLAME    = (240, 146, 60)

TRANSPARENT = (0, 0, 0, 0)


def new():
    return Image.new("RGBA", (S, S), TRANSPARENT)


def R(d, box, c, o=None, w=1):
    d.rectangle(box, fill=c, outline=o, width=w)


def E(d, box, c, o=None, w=1):
    d.ellipse(box, fill=c, outline=o, width=w)


def L(d, pts, c, w=1):
    d.line(pts, fill=c, width=w)


def P(d, pts, c, o=None):
    d.polygon(pts, fill=c)
    if o:
        d.line(list(pts) + [pts[0]], fill=o, width=1)


def text(d, xy, s, c=INK, size=9):
    try:
        f = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", size)
    except Exception:
        f = ImageFont.load_default()
    d.text(xy, s, fill=c, font=f)


# ---------- 通用器件 ----------
def bottle(liquid, symbol="", hazard=False, powder=False):
    """试剂瓶：玻璃 + 液面 + 标签；powder=True 时画粉末而非液面"""
    im = new(); d = ImageDraw.Draw(im)
    R(d, (12, 4, 19, 8), CORK, INK)                 # 瓶塞
    R(d, (13, 8, 18, 12), GLASS, INK)               # 瓶颈
    R(d, (7, 12, 24, 29), GLASS, INK)               # 瓶身
    if powder:
        R(d, (9, 20, 22, 27), liquid)
        for (x, y) in [(11, 19), (15, 18), (19, 19), (13, 22), (18, 22)]:
            R(d, (x, y, x + 1, y + 1), WHITE)
    else:
        R(d, (9, 18, 22, 27), liquid)               # 液体
        L(d, [(9, 18), (22, 18)], GLASS_HI)         # 液面高光
        R(d, (10, 21, 11, 25), GLASS_HI)            # 侧壁反光
    R(d, (8, 28, 23, 29), INK2)                     # 瓶底阴影
    R(d, (11, 15, 20, 22), WHITE, INK)              # 标签
    if symbol:
        text(d, (12, 15), symbol, INK, 7)
    if hazard:
        P(d, [(13, 23), (18, 23), (15.5, 18)], YELLOW, INK)
        text(d, (15, 19), "!", INK, 6)
    return im


def canister(color, symbol="", hazard=False):
    """耐压气罐：阀门 + 罐体 + 色带 + 飘散气泡"""
    im = new(); d = ImageDraw.Draw(im)
    R(d, (14, 2, 17, 6), METAL_D, INK)              # 阀门
    R(d, (11, 5, 20, 8), METAL, INK)                # 提手
    R(d, (9, 8, 22, 29), METAL, INK)                # 罐体
    E(d, (9, 8, 22, 13), METAL, INK)                # 顶弧
    E(d, (9, 25, 22, 30), METAL_D, INK)             # 底弧
    R(d, (9, 15, 22, 21), color)                    # 状态色带
    R(d, (11, 10, 12, 25), METAL_HI)                # 高光
    R(d, (12, 16, 19, 20), INK2)                    # 铭牌
    text(d, (13, 16), symbol, WHITE, 7)
    if hazard:
        P(d, [(20, 23), (25, 23), (22.5, 18)], YELLOW, INK)
    # 逸散气泡
    for (x, y, r) in [(25, 10, 2), (28, 6, 1), (26, 4, 1)]:
        E(d, (x - r, y - r, x + r, y + r), color, GAS_D)
    return im


def pile(color, hi=None, kind="lump"):
    """固体堆：底盘 + 块/粉 + 颗粒"""
    hi = hi or (min(255, color[0] + 40), min(255, color[1] + 40), min(255, color[2] + 40))
    im = new(); d = ImageDraw.Draw(im)
    E(d, (5, 24, 26, 30), (30, 34, 44, 90))
    if kind == "shard":
        P(d, [(7, 26), (12, 12), (16, 26)], color, INK)
        P(d, [(14, 26), (20, 15), (25, 26)], hi, INK)
        P(d, [(12, 26), (16, 19), (20, 26)], color, INK)
    else:
        P(d, [(5, 27), (9, 17), (15, 13), (21, 16), (26, 27)], color, INK)
        P(d, [(9, 17), (15, 13), (15, 27), (5, 27)], hi)
    for (x, y) in [(8, 22), (12, 25), (18, 21), (22, 24), (15, 17), (20, 26), (10, 27)]:
        R(d, (x, y, x + 1, y + 1), hi)
    return im


def crystal(color, lo=None):
    """晶体簇：多面菱形 + 高光面"""
    lo = lo or (max(0, color[0] - 60), max(0, color[1] - 60), max(0, color[2] - 40))
    im = new(); d = ImageDraw.Draw(im)
    E(d, (5, 26, 26, 30), (30, 34, 44, 80))
    P(d, [(9, 27), (6, 14), (12, 6), (16, 27)], color, INK)     # 主晶
    P(d, [(12, 6), (16, 27), (9, 27)], lo)                       # 暗面
    P(d, [(15, 27), (18, 11), (24, 8), (26, 27)], lo, INK)      # 副晶
    P(d, [(24, 8), (26, 27), (15, 27)], color)
    L(d, [(12, 6), (9, 27)], GLASS_HI)
    L(d, [(24, 8), (18, 11)], GLASS_HI)
    return im


# ---------- 玻璃器皿 / 容器 ----------
def glassware(kind):
    im = new(); d = ImageDraw.Draw(im)
    if kind == "beaker":
        R(d, (8, 9, 24, 29), GLASS, INK)
        R(d, (9, 19, 23, 27), WATER)
        L(d, [(9, 19), (23, 19)], GLASS_HI)
        L(d, [(7, 9), (25, 9)], INK, 2)                 # 杯口
        for yy in (13, 16, 22, 25):
            L(d, [(10, yy), (13, yy)], INK2)             # 刻度
        R(d, (10, 11, 11, 26), GLASS_HI)
    elif kind == "flask":
        R(d, (14, 5, 18, 14), GLASS, INK)               # 细颈
        P(d, [(14, 14), (5, 28), (27, 28), (18, 14)], GLASS, INK)
        P(d, [(9, 28), (12, 20), (20, 20), (23, 28)], ACID)
        L(d, [(12, 20), (20, 20)], GLASS_HI)
        L(d, [(13, 5), (19, 5)], INK, 2)
    elif kind == "graduated_cylinder":
        R(d, (12, 5, 20, 27), GLASS, INK)
        R(d, (13, 16, 19, 26), BASE)
        L(d, [(13, 16), (19, 16)], GLASS_HI)
        R(d, (8, 27, 24, 29), METAL_D, INK)             # 底座
        L(d, [(11, 5), (21, 5)], INK, 2)
        for yy in (9, 12, 15, 21, 24):
            L(d, [(13, yy), (16, yy)], INK2)
    elif kind == "vial":
        R(d, (10, 10, 22, 28), GLASS, INK)
        R(d, (12, 6, 20, 10), CORK, INK)
        R(d, (11, 18, 21, 27), SOLUTION)
        R(d, (12, 12, 13, 26), GLASS_HI)
        R(d, (13, 14, 19, 17), WHITE)
    elif kind == "pipette":
        R(d, (5, 4, 11, 9), RED, INK)                   # 胶头
        P(d, [(8, 9), (27, 26), (24, 29), (6, 11)], GLASS, INK)
        L(d, [(8, 10), (26, 27)], GLASS_HI)
        E(d, (24, 26, 28, 30), ACID, INK)               # 液滴
    elif kind == "gas_canister_empty":
        R(d, (14, 2, 17, 6), METAL_D, INK)
        R(d, (11, 5, 20, 8), METAL, INK)
        R(d, (9, 8, 22, 29), METAL, INK)
        E(d, (9, 8, 22, 13), METAL, INK)
        R(d, (9, 15, 22, 20), INK2)
        R(d, (11, 10, 12, 25), METAL_HI)
        text(d, (11, 15), "---", WHITE, 7)
    return im


# ---------- 工具 / 仪器 ----------
def instrument(kind):
    im = new(); d = ImageDraw.Draw(im)
    if kind == "balance":
        R(d, (6, 26, 26, 29), METAL_D, INK)
        R(d, (15, 10, 17, 26), METAL, INK)
        L(d, [(5, 12), (27, 12)], METAL_HI, 2)
        E(d, (14, 9, 18, 13), METAL, INK)
        for cx in (8, 24):
            L(d, [(cx, 12), (cx, 18)], INK)
            P(d, [(cx - 5, 18), (cx + 5, 18), (cx + 3, 22), (cx - 3, 22)], METAL, INK)
    elif kind == "ph_meter":
        R(d, (5, 8, 27, 27), METAL_D, INK)
        R(d, (7, 10, 25, 18), (40, 60, 52), INK)
        text(d, (11, 11), "pH 7", GREEN, 7)
        R(d, (9, 21, 23, 24), INK2)
        L(d, [(16, 27), (16, 30)], METAL)
        R(d, (7, 5, 11, 8), ACID, INK)                  # 试纸
    elif kind == "thermometer":
        R(d, (14, 4, 18, 24), GLASS, INK)
        E(d, (12, 22, 20, 30), RED, INK)
        R(d, (15, 12, 17, 26), RED)
        for yy in (7, 10, 13, 16, 19):
            L(d, [(18, yy), (21, yy)], INK2)
    elif kind == "spectrometer":
        R(d, (4, 12, 28, 27), METAL_D, INK)
        P(d, [(13, 13), (19, 13), (16, 8)], GLASS_HI, INK)   # 棱镜
        for i, c in enumerate([(220, 90, 90), (230, 180, 80), (150, 210, 110), (100, 170, 220), (160, 130, 210)]):
            L(d, [(20, 10 + i), (27, 12 + i * 2)], c, 1)
        R(d, (6, 21, 12, 25), INK2)
    elif kind == "goggles":
        R(d, (4, 12, 15, 22), GLASS, INK)
        R(d, (17, 12, 28, 22), GLASS, INK)
        R(d, (15, 15, 17, 17), INK)
        L(d, [(4, 13), (1, 12)], INK, 2)
        L(d, [(28, 13), (31, 12)], INK, 2)
        R(d, (6, 14, 7, 19), GLASS_HI)
        R(d, (19, 14, 20, 19), GLASS_HI)
    elif kind == "gas_mask":
        E(d, (7, 7, 25, 25), METAL_D, INK)
        E(d, (10, 11, 16, 17), GLASS, INK)
        E(d, (17, 11, 23, 17), GLASS, INK)
        R(d, (13, 20, 19, 27), INK2, INK)
        for yy in (22, 24):
            L(d, [(14, yy), (18, yy)], METAL)
        L(d, [(7, 12), (4, 10)], INK, 2)
        L(d, [(25, 12), (28, 10)], INK, 2)
    return im


# ---------- 机器 ----------
def machine(kind):
    im = new(); d = ImageDraw.Draw(im)
    # 通用机箱
    R(d, (3, 9, 28, 29), METAL_D, INK)
    R(d, (3, 9, 28, 12), METAL, INK)
    R(d, (5, 26, 26, 29), INK2)
    for x in (6, 25):
        E(d, (x - 1, 25, x + 1, 27), METAL)

    if kind == "reactor":
        E(d, (8, 12, 24, 28), GLASS, INK)               # 釜体
        E(d, (10, 18, 22, 27), ACID)                    # 反应液
        L(d, [(10, 18), (22, 18)], GLASS_HI)
        R(d, (15, 5, 17, 14), METAL, INK)               # 搅拌轴
        R(d, (12, 4, 20, 6), METAL_HI, INK)
        L(d, [(24, 16), (28, 16), (28, 22)], INK, 2)   # 出料管
        for (x, y) in [(13, 21), (17, 23), (20, 20)]:
            E(d, (x - 1, y - 1, x + 1, y + 1), WHITE)
    elif kind == "distiller":
        R(d, (7, 5, 12, 26), GLASS, INK)               # 塔柱
        R(d, (8, 14, 11, 25), WATER)
        for yy in (9, 12, 17, 20):
            L(d, [(7, yy), (12, yy)], INK2)
        L(d, [(12, 8), (20, 8), (20, 13)], INK, 2)     # 冷凝管
        for yy in (10, 12):
            L(d, [(20, yy), (25, yy)], INK, 1)
        R(d, (19, 18, 27, 28), GLASS, INK)             # 接收瓶
        R(d, (20, 23, 26, 27), WATER)
    elif kind == "electrolyzer":
        R(d, (6, 15, 26, 27), (60, 110, 130), INK)     # 电解液
        R(d, (10, 9, 12, 24), METAL_HI, INK)           # 电极 +
        R(d, (20, 9, 22, 24), METAL_D, INK)            # 电极 -
        text(d, (9, 5), "+", RED, 9)
        text(d, (20, 5), "-", BASE, 9)
        for (x, y) in [(14, 18), (17, 20), (15, 23), (18, 16)]:
            E(d, (x - 1, y - 1, x + 1, y + 1), WHITE)
    elif kind == "centrifuge":
        E(d, (6, 10, 26, 28), METAL, INK)              # 圆盖
        E(d, (9, 13, 23, 26), INK2, INK)
        E(d, (14, 17, 18, 22), GLASS_HI)
        for a in range(0, 360, 90):
            import math
            x = 16 + int(6 * math.cos(math.radians(a)))
            y = 19 + int(6 * math.sin(math.radians(a)))
            E(d, (x - 2, y - 2, x + 2, y + 2), WATER, INK)
        R(d, (23, 5, 27, 8), GREEN, INK)
    elif kind == "crystallizer":
        R(d, (6, 16, 26, 27), GLASS, INK)
        R(d, (7, 21, 25, 26), BASE)
        for (bx, by, s) in [(10, 16, 3), (17, 14, 4), (23, 17, 3)]:
            P(d, [(bx, by + s), (bx - s, by), (bx, by - s), (bx + s, by)], CRYSTAL, INK)
        L(d, [(7, 21), (25, 21)], GLASS_HI)
    elif kind == "compressor":
        E(d, (6, 12, 20, 29), METAL, INK)              # 压力罐
        E(d, (8, 15, 18, 27), GAS)
        E(d, (20, 8, 27, 15), WHITE, INK)              # 压力表
        L(d, [(23, 11), (25, 9)], RED, 1)
        L(d, [(20, 10), (16, 10)], INK, 2)
        R(d, (6, 9, 9, 14), METAL_D, INK)
    elif kind == "furnace":
        R(d, (5, 16, 27, 28), INK2, INK)               # 炉体
        R(d, (9, 12, 23, 18), METAL, INK)              # 坩埚
        P(d, [(12, 12), (14, 5), (17, 11), (19, 4), (21, 12)], FLAME, RED)
        P(d, [(15, 12), (16, 8), (18, 12)], YELLOW)
        R(d, (8, 24, 24, 27), RED)
    elif kind == "condenser":
        R(d, (5, 6, 27, 10), METAL, INK)
        R(d, (5, 22, 27, 26), METAL, INK)
        for x in range(7, 26, 5):
            L(d, [(x, 10), (x + 2, 22)], GLASS, 2)
            L(d, [(x, 10), (x + 2, 22)], INK2, 1)
        E(d, (14, 26, 18, 30), WATER, INK)             # 冷凝滴
    # 指示灯
    E(d, (24, 14, 26, 16), GREEN, INK)
    return im


# ---------- 清单 ----------
ICONS = []   # (key, 中文名, 分类, maker)

def add(key, name, cat, maker):
    ICONS.append((key, name, cat, maker))

# 试剂 · 液体
add("acid",              "酸液",       "试剂·液", lambda: bottle(ACID, "AC", True))
add("base",              "碱液",       "试剂·液", lambda: bottle(BASE, "BA", True))
add("solvent",           "溶剂",       "试剂·液", lambda: bottle((206, 222, 232), "SO"))
add("distilled_water",   "蒸馏水",     "试剂·液", lambda: bottle(WATER, "H2O"))
add("organic_oil",       "有机油",     "试剂·液", lambda: bottle(OIL, "OIL"))
add("solution",          "混合溶液",   "试剂·液", lambda: bottle(SOLUTION, "MIX"))
# 试剂 · 固体
add("salt_crystal",      "盐晶",       "试剂·固", lambda: crystal(WHITE, (170, 180, 196)))
add("sulfur",            "硫磺",       "试剂·固", lambda: pile(YELLOW, (250, 224, 120)))
add("carbon",            "碳粉",       "试剂·固", lambda: pile((58, 62, 72), (90, 96, 108)))
add("metal_scrap",       "金属屑",     "试剂·固", lambda: pile(METAL, METAL_HI, "shard"))
add("catalyst",          "催化剂粉",   "试剂·固", lambda: bottle((176, 132, 214), "CAT", powder=True))
add("crystal_product",   "结晶产物",   "试剂·固", lambda: crystal(CRYSTAL, CRYSTAL_D))
# 试剂 · 气体
add("gas_hydrogen",      "氢气罐",     "试剂·气", lambda: canister((96, 200, 210), "H2"))
add("gas_oxygen",        "氧气罐",     "试剂·气", lambda: canister((104, 148, 226), "O2"))
add("gas_chlorine",      "氯气罐",     "试剂·气", lambda: canister((196, 214, 96), "CL2", True))
add("gas_vapor",         "蒸汽罐",     "试剂·气", lambda: canister(GAS, "VAP"))
# 玻璃器皿 / 容器
add("beaker",            "烧杯",       "器皿",   lambda: glassware("beaker"))
add("flask",             "锥形瓶",     "器皿",   lambda: glassware("flask"))
add("graduated_cylinder","量筒",       "器皿",   lambda: glassware("graduated_cylinder"))
add("vial",              "安瓿瓶",     "器皿",   lambda: glassware("vial"))
add("pipette",           "移液管",     "器皿",   lambda: glassware("pipette"))
add("gas_canister_empty","空压气罐",   "器皿",   lambda: glassware("gas_canister_empty"))
# 工具 / 仪器
add("balance",           "精密天平",   "仪器",   lambda: instrument("balance"))
add("ph_meter",          "pH 计",      "仪器",   lambda: instrument("ph_meter"))
add("thermometer",       "温度计",     "仪器",   lambda: instrument("thermometer"))
add("spectrometer",      "光谱仪",     "仪器",   lambda: instrument("spectrometer"))
add("goggles",           "护目镜",     "防护",   lambda: instrument("goggles"))
add("gas_mask",          "防毒面具",   "防护",   lambda: instrument("gas_mask"))
# 机器
add("reactor",           "反应釜",     "机器",   lambda: machine("reactor"))
add("distiller",         "蒸馏塔",     "机器",   lambda: machine("distiller"))
add("electrolyzer",      "电解槽",     "机器",   lambda: machine("electrolyzer"))
add("centrifuge",        "离心机",     "机器",   lambda: machine("centrifuge"))
add("crystallizer",      "结晶器",     "机器",   lambda: machine("crystallizer"))
add("compressor",        "气体压缩机", "机器",   lambda: machine("compressor"))
add("furnace",           "高温炉",     "机器",   lambda: machine("furnace"))
add("condenser",         "冷凝盘管",   "机器",   lambda: machine("condenser"))

# 兜底产物：未匹配配方的废渣
def sludge():
    im = new(); d = ImageDraw.Draw(im)
    E(d, (4, 22, 27, 30), (30, 34, 44, 90))
    P(d, [(4, 27), (8, 17), (14, 14), (20, 18), (27, 27)], (72, 80, 66), INK)
    P(d, [(8, 17), (14, 14), (14, 27), (4, 27)], (96, 106, 84))
    for (x, y, c) in [(10, 21, SOLUTION), (17, 20, ACID), (21, 24, OIL), (13, 25, (150, 160, 140))]:
        E(d, (x - 2, y - 1, x + 2, y + 2), c, INK2)
    for (x, y) in [(6, 24), (12, 19), (19, 23), (24, 26)]:
        E(d, (x - 1, y - 1, x + 1, y + 1), WHITE)
    return im

add("sludge",            "废渣",       "副产物", sludge)


def preview():
    """模组菜单预览图：4x3 图标拼贴 + 标题条"""
    w, h, s = 320, 200, 48
    im = Image.new("RGBA", (w, h), (24, 28, 38, 255)); d = ImageDraw.Draw(im)
    try:
        f = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 18)
        small = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 10)
    except Exception:
        f = ImageFont.load_default(); small = ImageFont.load_default()
    R(d, (0, 0, w, 34), (34, 44, 62))
    d.text((12, 6), "FreeChem 自由化学", fill=(240, 244, 250), font=f)
    d.text((12, 176), "solid / liquid / gas  ·  8 machines  ·  free reactions", fill=(150, 165, 185), font=small)
    picks = ["acid", "base", "salt_crystal", "gas_chlorine", "reactor", "distiller",
             "beaker", "spectrometer", "crystal_product", "gas_hydrogen", "furnace", "ph_meter"]
    for i, k in enumerate(picks):
        mk = next((m for kk, _, _, m in ICONS if kk == k), None)
        if mk is None: continue
        ic = mk().resize((s, s), Image.NEAREST)
        x, y = 12 + (i % 6) * 50, 44 + (i // 6) * 62
        d.rectangle((x - 2, y - 2, x + s + 2, y + s + 2), fill=(38, 44, 58), outline=(60, 70, 90))
        im.alpha_composite(ic, (x, y))
    return im


def main():
    for key, name, cat, maker in ICONS:
        maker().save(os.path.join(OUT, key + ".png"))
    preview().convert("RGB").save(
        r"C:\Users\Administrator\WorkBuddy\Claw\ps-chem-mod\FreeChem\preview.png")

    # 总览图：8 列，3 倍放大，带中文标签
    cell, scale, cols = 32, 3, 8
    cw, ch = cell * scale, cell * scale + 20
    rows = (len(ICONS) + cols - 1) // cols
    sheet = Image.new("RGBA", (cols * cw, rows * ch + 44), (24, 28, 38, 255))
    sd = ImageDraw.Draw(sheet)
    try:
        title_f = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 22)
        label_f = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 12)
    except Exception:
        title_f = ImageFont.load_default(); label_f = ImageFont.load_default()
    sd.text((16, 10), "FreeChem · 自由化学 Mod — 图标资产总览", fill=(240, 244, 250), font=title_f)
    for i, (key, name, cat, maker) in enumerate(ICONS):
        cx, cy = (i % cols) * cw, 44 + (i // cols) * ch
        icon = maker().resize((cell * scale, cell * scale), Image.NEAREST)
        sd.rectangle((cx + 2, cy + 2, cx + cw - 2, cy + cell * scale + 2), fill=(38, 44, 58), outline=(60, 70, 90))
        sheet.alpha_composite(icon, (cx, cy))
        sd.text((cx + 4, cy + cell * scale + 3), name, fill=(222, 230, 240), font=label_f)
    sheet.convert("RGB").save(SHEET)
    print(f"generated {len(ICONS)} icons -> {OUT}")
    print("sheet ->", SHEET)


if __name__ == "__main__":
    main()
