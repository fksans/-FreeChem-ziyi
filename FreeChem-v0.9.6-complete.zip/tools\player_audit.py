# -*- coding: utf-8 -*-
"""
只读玩家视角审计脚本（player-reviewer 临时工具，不修改任何游戏代码）。
从 src/*.cs 与 FreeChem/* 解析出物品台账 / 反应表 / 获取来源 / 用途 / 经济数值。
输出纯文本报告，供人工撰写 docs/player-perspective-review.md。
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")


def read(name):
    with open(os.path.join(SRC, name), encoding="utf-8-sig") as f:
        return f.read()


catalog = read("ChemCatalog.cs")
recipes = read("ChemRecipes.cs")
lab = read("ChemLab.cs")
machines = read("ChemMachines.cs")
modentry = read("ModEntry.cs")
phone = read("ChemPhone.cs")

# ── 1) 解析 ChemCatalog.Specs ─────────────────────────────────────────────
specs = []
grade_purity = {"Industrial": 70, "Medical": 95, "UltraPure": 99}

for m in re.finditer(
    r'S\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*Phase\.(\w+)\s*,\s*PurityGrade\.(\w+)\s*,'
    r'\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*"([^"]*)"\s*\)',
    catalog,
):
    iid, formula, phase, grade, value, purity, hazard, kind = m.groups()
    specs.append(dict(id=iid, formula=formula, phase=phase, grade=grade,
                      value=int(value), purity=int(purity), hazard=int(hazard),
                      kind=kind, medical=False, controlled=False, ctor="S"))

for m in re.finditer(
    r'C\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*PurityGrade\.(\w+)\s*,\s*(-?\d+)\s*,\s*(true|false)\s*\)',
    catalog,
):
    iid, formula, grade, value, med = m.groups()
    specs.append(dict(id=iid, formula=formula, phase="Gas", grade=grade,
                      value=int(value), purity=grade_purity[grade],
                      hazard=3 if formula == "Cl2" else 1, kind="canister",
                      medical=(med == "true"), controlled=False, ctor="C"))

for m in re.finditer(r'I\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*(-?\d+)\s*\)', catalog):
    iid, formula, value = m.groups()
    specs.append(dict(id=iid, formula=formula, phase="Solid", grade="Industrial",
                      value=int(value), purity=70, hazard=3, kind="illicit",
                      medical=False, controlled=True, ctor="I"))

by_id = {s["id"]: s for s in specs}
assert len(by_id) == len(specs), "重复 id!"

# ── 2) 解析反应表 ────────────────────────────────────────────────────────
# 把 All 数组切成单条 new Reaction(...) 块（按括号配平）
def split_blocks(text, marker, open_c="(", close_c=")"):
    out = []
    for m in re.finditer(re.escape(marker), text):
        i = m.start()
        j = text.find(open_c, i)
        depth = 0
        k = j
        while k < len(text):
            if text[k] == open_c:
                depth += 1
            elif text[k] == close_c:
                depth -= 1
                if depth == 0:
                    break
            k += 1
        out.append(text[i:k + 1])
    return out


def strs(block):
    return re.findall(r'"([^"]*)"', block)


reactions = []
all_block = recipes[recipes.index("public static readonly Reaction[] All"):recipes.index("public static readonly string[] MachineIds")]
for blk in split_blocks(all_block, "new Reaction("):
    s = strs(blk)
    rid, name, eq, machine = s[0], s[1], s[2], s[3]
    # tier = 第 4 个参数（machine）之后的第一个整数
    tail = blk[blk.index('"' + machine + '"') + len(machine) + 2:]
    tier = int(re.search(r"\d+", tail).group())
    # 更稳：按 new[]{...} 抓两组
    arrs = re.findall(r"new\[\]\s*\{([^}]*)\}", blk)
    inputs = re.findall(r'"([^"]+)"', arrs[0]) if arrs else []
    outputs = re.findall(r'"([^"]+)"', arrs[1]) if len(arrs) > 1 else []
    temp = re.search(r"temp:\s*(\d+)", blk)
    ph = re.search(r"ph:\s*(-?\d+)", blk)
    hazard = re.search(r"hazard:\s*(\d+)", blk)
    reactions.append(dict(
        id=rid, name=name, equation=eq, machine=machine, tier=tier,
        inputs=inputs, outputs=outputs,
        temp=int(temp.group(1)) if temp else 1,
        ph=int(ph.group(1)) if ph else -1,
        hazard=int(hazard.group(1)) if hazard else 0,
        needs_catalyst="needsCatalyst: true" in blk,
        catalyst_bonus="catalystBonus: true" in blk,
        uses_vanilla="usesVanilla: true" in blk,
    ))

thermal = []
lab_block = lab[lab.index("public static readonly ThermalReaction[] ThermalReactions"):lab.index("public static ThermalReaction MatchThermal")]
for blk in split_blocks(lab_block, "new ThermalReaction("):
    arrs = re.findall(r"new\[\]\s*\{([^}]*)\}", blk)
    inputs = re.findall(r'"([^"]+)"', arrs[0]) if arrs else []
    outputs = re.findall(r'"([^"]+)"', arrs[1]) if len(arrs) > 1 else []
    s = strs(blk)
    nums = re.findall(r",\s*([\d.]+)f?\s*,\s*([\d.]+)f?\s*,\s*([\d.]+)f?\s*,\s*(\d+)\s*\)", blk)
    mn = mx = dg = None
    secs = None
    if nums:
        mn, mx, dg, secs = (float(nums[0][0]), float(nums[0][1]), float(nums[0][2]), int(nums[0][3]))
    thermal.append(dict(id=s[0], name=s[1], equation=s[2], inputs=inputs, outputs=outputs,
                        min=mn, max=mx, degrade=dg, seconds=secs,
                        uses_vanilla="usesVanilla: true" in blk))

# ── 3) 掉落 / 起始 / 订单 / 发明家 来源 ──────────────────────────────────
with open(os.path.join(ROOT, "FreeChem", "LootTables", "free_chem_drops.json"), encoding="utf-8-sig") as f:
    loot = json.load(f)

loot_source = {}
for tbl in loot["tables"]:
    for e in tbl["entries"]:
        loot_source.setdefault(e["id"], []).append(("%s(w=%d)" % (tbl["id"], e["weight"])))
for p in loot["patches"]:
    if "table" in p:
        for e in p.get("add", []):
            loot_source.setdefault(e["id"], []).append(("%s(w=%d)" % (p["table"], e["weight"])))

def array_block(text, marker, endmarker):
    seg = text[text.index(marker):text.index(endmarker, text.index(marker))]
    return re.findall(r'"([^"]+)"', seg)

starter = array_block(modentry, "foreach (var id in new[] {", "})")
gasorder = array_block(modentry, 'string[] pack = {', "};")
apparatus = array_block(modentry, "static readonly string[] ApparatusIds =", "};")
canister_skus = {}
for m in re.finditer(r'\{\s*"(gas_\w+)"\s*,\s*new\[\]\s*\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\}\s*\}', recipes):
    canister_skus[m.group(1)] = [m.group(2), m.group(3), m.group(4)]
drum_skus = {}
for m in re.finditer(r'\{\s*"(gas_\w+)"\s*,\s*"(gas_drum_\w+)"\s*\}', recipes):
    drum_skus[m.group(1)] = m.group(2)
machine_ids = array_block(recipes, "public static readonly string[] MachineIds =", "};")
vanilla_analog = {}
for m in re.finditer(r'\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\}', recipes[recipes.index("VanillaAnalog"):recipes.index("public static string Normalize")]):
    vanilla_analog[m.group(1)] = m.group(2)
order_pack = array_block(phone, "public static readonly string[] OrderPack =", "};")

# ── 4) 汇总来源 / 用途 ───────────────────────────────────────────────────
sources = {s["id"]: set() for s in specs}
for s in specs:
    i = s["id"]
    if i in loot_source:
        sources[i].add("掉落:" + ",".join(sorted(set(loot_source[i]))))
    if i in starter:
        sources[i].add("起始礼包")
    if i in gasorder:
        sources[i].add("气体订单($120)")
    if i in apparatus:
        sources[i].add("发明家库存")
    if i in order_pack:
        sources[i].add("电话订购($320包)")
    if i in machine_ids:
        sources[i].add("机器(发明家库存/调试)")
    if i in ("gas_canister_empty", "sol_sodium_chloride"):
        sources[i].add("发明家库存直售")
    if i in vanilla_analog.values():
        sources[i].add("原版物品折算")
for r in reactions:
    for o in r["outputs"]:
        if o in sources:
            sources[o].add("反应:" + r["id"])
for t in thermal:
    for o in t["outputs"]:
        if o in sources:
            sources[o].add("热反应:" + t["id"])
for gas, skus in canister_skus.items():
    for sku in skus:
        if sku in sources:
            sources[sku].add("灌装台(需" + gas + ")")
for gas, drum in drum_skus.items():
    if drum in sources:
        sources[drum].add("灌装台(需" + gas + ")")

uses = {s["id"]: set() for s in specs}
for r in reactions:
    for i in r["inputs"]:
        if i in uses:
            uses[i].add("反应:" + r["id"])
for t in thermal:
    for i in t["inputs"]:
        if i in uses:
            uses[i].add("热反应:" + t["id"])
# 特殊用途
special = {
    "thermometer": "全局温度档切换(点击)",
    "ph_meter": "全局 pH 档切换(点击)",
    "precision_balance": "全局「配平」开关(催化剂加成条件)",
    "safety_goggles": "全局「防护」开关(hazard>=2 配方不再产废渣)",
    "catalyst_kit": "机器投料槽：needsCatalyst 配方条件+产率加成；打印机校准充能",
    "label_printer": "给本模组药剂盖纯度/品级标签(可造假)",
    "gas_canister_empty": "灌装台空容器→can_*；机器气瓶槽(装气后)",
    "gas_drum_empty": "灌装台空容器→gas_drum_*",
    "alcohol_lamp": "加热台加热器槽(需灯芯+燃料)；点击切高档",
    "spirit_burner": "加热台加热器槽；点击切高档",
    "wick_cotton": "加热台灯芯槽(耐久20)",
    "wick_ceramic": "加热台灯芯槽(耐久40)",
    "filter_paper": "过滤台滤纸槽(孔径22μm,耐久8)",
    "filter_paper_fine": "过滤台滤纸槽(孔径5μm,耐久5)",
    "filter_paper_ash": "过滤台滤纸槽(孔径2μm,耐久3)",
    "beaker": "加热台反应槽(纯展示，不参与匹配)",
    "retort_flask": "加热台反应槽(纯展示)",
    "erlenmeyer_flask": "加热台反应槽(纯展示)",
    "test_tube_rack": "加热台反应槽(纯展示)",
    "liq_ethanol": "加热台燃料槽(燃料)；热反应原料",
    "sludge": "事故/失败产物(可卖)",
}
for k, v in special.items():
    if k in uses:
        uses[k].add(v)
for gas in canister_skus:
    pass
# 气瓶：可作为气体源(气瓶槽)
for sku, gas in [(s2, g) for g, skus in canister_skus.items() for s2 in skus]:
    if sku in uses:
        uses[sku].add("气瓶槽供气→" + gas)

# ── 5) 报告 ──────────────────────────────────────────────────────────────
print("=" * 100)
print("A. 物品台账：Specs 总数 = %d ；MachineIds = %d ；反应(夜间) = %d ；热反应 = %d"
      % (len(specs), len(machine_ids), len(reactions), len(thermal)))
print("   数字 ID 表 Ordered 条目 = ", len(re.findall(r'"[^"]+",', read("ChemItemIds.cs"))))
print("=" * 100)

kinds = {}
for s in specs:
    kinds.setdefault(s["kind"], []).append(s["id"])
print("\n[类别分布]")
for k in sorted(kinds):
    print("  %-12s %2d 件: %s" % (k, len(kinds[k]), ", ".join(kinds[k])))

print("\n" + "=" * 100)
print("B. 逐物品表：id | 类别 | 相态 | 价格 | 纯度 | 危险 | 来源 | 用途条数 | 用途摘要")
print("=" * 100)
no_source = []
no_use = []
for s in sorted(specs, key=lambda x: (x["kind"], x["id"])):
    i = s["id"]
    src = sources[i]
    use = uses[i]
    if not src:
        no_source.append(i)
        srctxt = "【无来源】"
    else:
        srctxt = ";".join(sorted(src))
    if not use:
        no_use.append(i)
        usetxt = "【无用途】"
    else:
        usetxt = ";".join(sorted(use))
    print("-" * 96)
    print("%-28s %-9s %-6s $%-5d p%-3d h%d" % (i, s["kind"], s["phase"], s["value"], s["purity"], s["hazard"]))
    print("   来源: " + srctxt)
    print("   用途: " + usetxt)

print("\n" + "=" * 100)
print("C. 问题清单")
print("=" * 100)
print("\n[C1] 无任何获取来源（死物品）共 %d 件：" % len(no_source))
for i in no_source:
    print("   -", i, by_id[i]["value"], by_id[i]["kind"])
print("\n[C2] 无任何用途（只能卖/纯装饰）共 %d 件：" % len(no_use))
for i in no_use:
    print("   -", i, "value=%d" % by_id[i]["value"], "kind=%s" % by_id[i]["kind"],
          "source=%s" % (sorted(sources[i]) or "无"))
print("\n[C3] 有来源但用途仅为「能卖」的（既非投料也非设备/工具）：")
for s in specs:
    i = s["id"]
    if sources[i] and not uses[i]:
        print("   -", i, "value=%d" % s["value"], "|", ";".join(sorted(sources[i])))

print("\n" + "=" * 100)
print("D. 反应经济：投入总价值 → 产出总价值（按 unitValue 粗算，忽略纯度加成）")
print("=" * 100)
for r in reactions:
    iv = sum(by_id[i]["value"] for i in r["inputs"] if i in by_id)
    ov = sum(by_id[i]["value"] for i in r["outputs"] if i in by_id)
    extra = ""
    if r["catalyst_bonus"]:
        extra = "  [配平+催化剂时首产物×2]"
    delta = ov - iv
    flag = ""
    if iv > 0 and ov > iv * 2:
        flag = "  <== 产出价值 > 投入 2 倍"
    if iv > 0 and ov > 0 and ov < iv * 0.5:
        flag = "  <-- 严重亏本"
    print("  %-22s %-20s T%d %9s -> %9s  delta=%+6d%s%s"
          % (r["id"], r["machine"], r["tier"], "$%d" % iv, "$%d" % ov, delta, extra, flag))

print("\n[热反应经济]（只算已登记价值的投入品）")
for t in thermal:
    iv = sum(by_id[i]["value"] for i in t["inputs"] if i in by_id)
    ov = sum(by_id[i]["value"] for i in t["outputs"] if i in by_id)
    print("  %-24s %8s -> %8s  delta=%+6d  温区 %s-%s 降解 %s 需 %ss"
          % (t["id"], "$%d" % iv, "$%d" % ov, ov - iv, t["min"], t["max"], t["degrade"], t["seconds"]))

print("\n" + "=" * 100)
print("E. 危险度(accident)门禁：hazard>=2 且默认 Protected=false 时只产废渣")
print("=" * 100)
for r in reactions:
    if r["hazard"] >= 2:
        print("  %-22s hazard=%d machine=%-18s T%d inputs=%s"
              % (r["id"], r["hazard"], r["machine"], r["tier"], "+".join(r["inputs"])))

print("\n" + "=" * 100)
print("F. T4 路径可达性（默认设置）")
print("=" * 100)
for r in reactions:
    if r["tier"] == 4:
        print("  %-12s machine=%-20s temp=%d catalyst=%s inputs=%s"
              % (r["id"], r["machine"], r["temp"], r["needs_catalyst"], "+".join(r["inputs"])))
print("\n  温度档使用统计：")
tt = {}
for r in reactions:
    tt[r["temp"]] = tt.get(r["temp"], 0) + 1
print("   ", tt, " (0/1 档在任意温度下都匹配; 2/3 档必须全局温度完全一致)")

print("\n" + "=" * 100)
print("G. 纯度/档位与售价（canister 才有品级加成 PricedValue）")
print("=" * 100)
for s in specs:
    if s["kind"] == "canister":
        bonus = {"Industrial": 0, "Medical": 85, "UltraPure": 135}[s["grade"]]
        print("  %-28s value=%-4d grade=%-10s PricedValue=%d"
              % (s["id"], s["value"], s["grade"], s["value"] + s["value"] * bonus // 100))

print("\n" + "=" * 100)
print("H. 掉落表权重分布")
print("=" * 100)
for tbl in loot["tables"]:
    tot = sum(e["weight"] for e in tbl["entries"])
    print("  %s: %d 条, 权重和 %d" % (tbl["id"], len(tbl["entries"]), tot))
    for e in tbl["entries"]:
        print("     %-28s w=%-4d 占比 %.2f%%" % (e["id"], e["weight"], 100.0 * e["weight"] / tot))
