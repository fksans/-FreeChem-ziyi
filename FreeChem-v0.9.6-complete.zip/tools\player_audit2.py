# -*- coding: utf-8 -*-
"""只读文案/一致性核对脚本（player-reviewer 临时工具）。"""
import json
import os
import re
import sys
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")


def read(n):
    with open(os.path.join(SRC, n), encoding="utf-8-sig") as f:
        return f.read()


catalog = read("ChemCatalog.cs")
recipes = read("ChemRecipes.cs")
itemids = read("ChemItemIds.cs")

# Specs / machines
specs = []
for m in re.finditer(r'S\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*Phase\.(\w+)\s*,', catalog):
    specs.append(dict(id=m.group(1), formula=m.group(2), phase=m.group(3), kind=None))
for m in re.finditer(r'C\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,', catalog):
    specs.append(dict(id=m.group(1), formula=m.group(2), phase="Gas", kind="canister"))
for m in re.finditer(r'I\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,', catalog):
    specs.append(dict(id=m.group(1), formula=m.group(2), phase="Solid", kind="illicit"))
machines = re.findall(r'"([a-z_]+)"', recipes[recipes.index("public static readonly string[] MachineIds ="):recipes.index("public static bool IsRealtime")])
order = re.findall(r'"([^"]+)"', itemids[itemids.index("public static readonly string[] Ordered"):itemids.index("public static bool TryGetId")])

print("Specs 条目 =", len(specs))
print("Ordered 条目 =", len(order), " MaxId =", re.search(r"MaxId = (\d+)", itemids).group(1))
print("MachineIds 条目 =", len(machines), machines)

# 本地化
def load_csv(p):
    d = {}
    with open(p, encoding="utf-8-sig") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            if "," in line:
                k, v = line.split(",", 1)
                d[k.strip()] = v
    return d


zh = load_csv(os.path.join(ROOT, "FreeChem", "Localization", "zh.csv"))
en = load_csv(os.path.join(ROOT, "FreeChem", "Localization", "en.csv"))
print("zh 键 = %d ; en 键 = %d ; 差异 zh-en = %s ; en-zh = %s"
      % (len(zh), len(en), len(set(zh) - set(en)), len(set(en) - set(zh))))

missing = []
for s in specs:
    for suf in ("_name", "_desc", "_flavor"):
        if s["id"] + suf not in zh:
            missing.append(s["id"] + suf)
for m in machines:
    for suf in ("_name", "_desc", "_flavor"):
        if m + suf not in zh:
            missing.append(m + suf)
print("缺失中文本地化 =", missing if missing else "无")

# 索引书覆盖
idx = json.load(open(os.path.join(ROOT, "FreeChem", "Books", "chem_index.json"), encoding="utf-8-sig"))
idx_ids = []
for p in idx["pages"]:
    for el in p["elements"]:
        if el.get("type") == "text" and "translations" in el:
            idx_ids += re.findall(r"ID\s+(\d+)", el["translations"]["zh"])
print("索引书页数 = %d ; 覆盖 ID 数 = %d (%s..%s)"
      % (len(idx["pages"]), len(idx_ids), min(int(x) for x in idx_ids), max(int(x) for x in idx_ids)))
print("索引书条目 = Ordered 顺序一致:", idx_ids == [str(i + 1) for i in range(len(order))])

# flavor 重复度
fl = Counter(zh.get(s["id"] + "_flavor", "") for s in specs)
print("\n物品 flavor 文本重复统计（共 %d 件物品）：" % len(specs))
for text, n in fl.most_common(5):
    print("   x%-3d %s" % (n, text[:60]))

# 开发术语泄漏扫描
jargon = ["P1b1", "P1c", "P3a", "P3b", "P3c", "P3d", "P3e", "P2a", "P4a", "P4d", "P5a", "P5b",
          "P6a", "T4", "T3", "掉落表", "free_chem_", "未实机验证", "实机", "bug", "BUG",
          "调试", "数字 ID", "本模组", "legacy", "原版桥接", "1–85", "1-85", "1–96", "1-96",
          "0.7%", "μl", "part", "API", "Harmony", "ModData", "tag", "tag ", "TMP"]
print("\n[开发术语/版本号泄漏扫描]（玩家可见的陆文/手册文本）")
targets = {}
for k, v in zh.items():
    targets[k] = v
for suffix in ["_desc", "_flavor"]:
    hits = []
    for k, v in targets.items():
        if not k.endswith(suffix):
            continue
        for j in jargon:
            if j in v:
                hits.append((k, j, v[:80]))
                break
    print("  %-8s 命中 %d 条:" % (suffix, len(hits)))
    for k, j, v in hits:
        print("    %-34s [%s] %s" % (k, j, v))

# 手册代词
codex = json.load(open(os.path.join(ROOT, "FreeChem", "Books", "chem_codex.json"), encoding="utf-8-sig"))
print("\n[手册 chem_codex.json 开发术语扫描]")
for page in codex["pages"]:
    for el in page["elements"]:
        if el.get("type") != "text" or "translations" not in el:
            continue
        txt = el["translations"].get("zh", "")
        found = [j for j in jargon if j in txt]
        if found:
            print("  页 %-22s 命中: %s" % (page["name"], sorted(set(found))))

# 机器描述 vs AllowedInputPhases 矛盾检查
allowed = {
    "decanter": ["Liquid"], "gas_scrubber": ["Gas"], "canister_filling": ["Gas"],
    "condenser_unit": ["Gas", "Liquid"], "crystallizer": ["Liquid"],
}
print("\n[机器描述 vs 代码相态限制]")
for m in machines:
    key = m + "_desc"
    desc = zh.get(key, "")
    if m in allowed:
        print("  %-20s 代码允许=%s" % (m, allowed[m]))
        print("      描述: %s" % desc)

# 描述里出现「仅接受气体/仅接受液体」的机器
print("\n[含「仅接受」句的机器描述]")
for m in machines:
    d = zh.get(m + "_desc", "")
    if "仅接受" in d:
        print("  %-20s %s" % (m, d))

# 数值/键一致性：MaxId vs 手册/本地化里的 85/96
print("\n[数字 ID 上限声明扫描]")
for k, v in zh.items():
    if "85" in v or "96" in v or "97" in v:
        print("  %-30s %s" % (k, v[:100]))
