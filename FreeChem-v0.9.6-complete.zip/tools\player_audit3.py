# -*- coding: utf-8 -*-
"""只读：机器输出格容量 vs 每条反应产物占格；输入槽数 vs 配方需求。"""
import os
import re
import struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")


def read(n):
    with open(os.path.join(SRC, n), encoding="utf-8-sig") as f:
        return f.read()


mach = read("ChemMachines.cs")
recipes = read("ChemRecipes.cs")

# 图标占格
cells = {}
tdir = os.path.join(ROOT, "FreeChem", "Textures", "Items")
for f in os.listdir(tdir):
    if not f.endswith(".png") or f.endswith("_on.png"):
        continue
    with open(os.path.join(tdir, f), "rb") as fh:
        hdr = fh.read(33)
    w, h = struct.unpack(">II", hdr[16:24])
    cells[f[:-4]] = ((w // 16) * (h // 16), w // 16, h // 16)

# LayoutOf 输出尺寸/输入槽
layout = {}
for m in re.finditer(
    r'case "(\w+)":\s*\n\s*return new MachineLayout \{([^}]*)\}', mach):
    mid, body = m.group(1), m.group(2)
    ow = re.search(r"OutputW = (\d+)", body)
    oh = re.search(r"OutputH = (\d+)", body)
    ins = re.search(r"InputSlots = (\d+)", body)
    layout[mid] = dict(
        out=(int(ow.group(1)) if ow else 3) * (int(oh.group(1)) if oh else 3),
        outw=int(ow.group(1)) if ow else 3,
        outh=int(oh.group(1)) if oh else 3,
        ins=int(ins.group(1)) if ins else 2,
        filter="FilterSlot = true" in body,
        container="ContainerSlot = true" in body,
    )
layout["heating_platform"] = dict(out=18, outw=6, outh=3, ins=0, filter=False, container=False)
layout["filtration_bench"] = layout.get("filtration_bench", dict(out=9, outw=3, outh=3, ins=1, filter=True, container=False))

# 反应
reactions = []
all_block = recipes[recipes.index("public static readonly Reaction[] All"):recipes.index("public static readonly string[] MachineIds")]
for m in re.finditer(r"new Reaction\(", all_block):
    i = m.start()
    j = all_block.find("(", i)
    depth = 0
    k = j
    while k < len(all_block):
        if all_block[k] == "(":
            depth += 1
        elif all_block[k] == ")":
            depth -= 1
            if depth == 0:
                break
        k += 1
    blk = all_block[i:k + 1]
    s = re.findall(r'"([^"]*)"', blk)
    arrs = re.findall(r"new\[\]\s*\{([^}]*)\}", blk)
    inp = re.findall(r'"([^"]+)"', arrs[0])
    out = re.findall(r'"([^"]+)"', arrs[1])
    mach_id = s[3]
    bonus = "catalystBonus: true" in blk
    reactions.append(dict(id=s[0], machine=mach_id, inputs=inp, outputs=out, bonus=bonus))

print("=" * 96)
print("输出格容量 vs 产物占格（按图标 16px 格计算；气体/钢瓶 2x3=6 格，液体 1x3=3 格，固体 1 格）")
print("=" * 96)
bad = []
for r in reactions:
    L = layout.get(r["machine"])
    if not L:
        print("  !! 未知机器", r["machine"])
        continue
    need = sum(cells.get(o, (1, 1, 1))[0] for o in r["outputs"])
    if r["bonus"]:
        need += cells.get(r["outputs"][0], (1, 1, 1))[0]
    flag = ""
    if need > L["out"]:
        flag = "   <== 超出输出格 %d 格" % (need - L["out"])
        bad.append((r["id"], r["machine"], need, L["out"]))
    print("  %-22s %-18s 输出格 %2d  需要 %2d  %s%s"
          % (r["id"], r["machine"], L["out"], need,
             "+".join("%s(%d格)" % (o, cells.get(o, (1, 1, 1))[0]) for o in r["outputs"]), flag))

print("\n超出输出格的配方 %d 条:" % len(bad))
for x in bad:
    print("   ", x)

print("\n" + "=" * 96)
print("输入槽 vs 配方非容器投料数（含 gas 由气瓶槽提供的情形未计入）")
print("=" * 96)
for r in reactions:
    L = layout.get(r["machine"], {})
    ins = L.get("ins", 0)
    need = len([i for i in r["inputs"] if not (i == "gas_canister_empty" or i == "gas_drum_empty")])
    extra = ""
    if r["machine"] == "canister_filling":
        extra = " (+空容器专用槽)"
    elif r["machine"] == "filtration_bench":
        extra = " (+滤纸专用槽)"
    flag = "   <== 槽位不足" if need > ins else ""
    print("  %-22s %-18s 投料槽 %d  需求 %d%s%s" % (r["id"], r["machine"], ins, need, extra, flag))
