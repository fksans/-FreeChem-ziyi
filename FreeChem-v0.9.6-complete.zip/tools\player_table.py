# -*- coding: utf-8 -*-
"""生成玩家视角报告的物品 Markdown 表（tools/item_table.md）。只读数据源。"""
import json
import os
import re
import struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")


def read(n):
    with open(os.path.join(SRC, n), encoding="utf-8-sig") as f:
        return f.read()


catalog = read("ChemCatalog.cs")
recipes = read("ChemRecipes.cs")
lab = read("ChemLab.cs")
modentry = read("ModEntry.cs")
phone = read("ChemPhone.cs")
itemids = read("ChemItemIds.cs")

grade_purity = {"Industrial": 70, "Medical": 95, "UltraPure": 99}
specs = []
for m in re.finditer(r'S\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*Phase\.(\w+)\s*,\s*PurityGrade\.(\w+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*"([^"]*)"\s*\)', catalog):
    specs.append(dict(id=m.group(1), formula=m.group(2), phase=m.group(3), grade=m.group(4),
                      value=int(m.group(5)), purity=int(m.group(6)), hazard=int(m.group(7)),
                      kind=m.group(8), medical=False, controlled=False))
for m in re.finditer(r'C\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*PurityGrade\.(\w+)\s*,\s*(-?\d+)\s*,\s*(true|false)\s*\)', catalog):
    g = m.group(3)
    specs.append(dict(id=m.group(1), formula=m.group(2), phase="Gas", grade=g,
                      value=int(m.group(4)), purity=grade_purity[g], hazard=3 if m.group(2) == "Cl2" else 1,
                      kind="canister", medical=(m.group(5) == "true"), controlled=False))
for m in re.finditer(r'I\(\s*"([^"]+)"\s*,\s*"([^"]*)"\s*,\s*(-?\d+)\s*\)', catalog):
    specs.append(dict(id=m.group(1), formula=m.group(2), phase="Solid", grade="Industrial",
                      value=int(m.group(3)), purity=70, hazard=3, kind="illicit",
                      medical=False, controlled=True))
by_id = {s["id"]: s for s in specs}

# 占格：按 16px 格中心 alpha 采样（与游戏 SetSpriteAndShapeFromMod 同规则）
cells = {}
try:
    from PIL import Image
    tdir = os.path.join(ROOT, "FreeChem", "Textures", "Items")
    for f in os.listdir(tdir):
        if not f.endswith(".png") or f.endswith("_on.png"):
            continue
        im = Image.open(os.path.join(tdir, f)).convert("RGBA")
        w, h = im.size
        px = im.load()
        n = 0
        for cy in range(h // 16):
            for cx in range(w // 16):
                if px[min(w - 1, cx * 16 + 8), min(h - 1, cy * 16 + 8)][3] > 0:
                    n += 1
        cells[f[:-4]] = "%d×%d=%d格" % (w // 16, h // 16, n)
except Exception as e:
    print("PIL 采样失败:", e)


def block(text, marker, endmarker):
    seg = text[text.index(marker):text.index(endmarker, text.index(marker))]
    return re.findall(r'"([^"]+)"', seg)


# 反应
reactions = []
all_block = recipes[recipes.index("public static readonly Reaction[] All"):recipes.index("public static readonly string[] MachineIds")]
for m in re.finditer(r"new Reaction\(", all_block):
    i = m.start()
    j = all_block.find("(", i)
    depth = 0
    k = j
    while k < len(all_block):
        if all_block[k] == "(":
            depth += 1
        elif all_block[k] == ")":
            depth -= 1
            if depth == 0:
                break
        k += 1
    blk = all_block[i:k + 1]
    s = re.findall(r'"([^"]*)"', blk)
    arrs = re.findall(r"new\[\]\s*\{([^}]*)\}", blk)
    reactions.append(dict(id=s[0], machine=s[3],
                          inputs=re.findall(r'"([^"]+)"', arrs[0]),
                          outputs=re.findall(r'"([^"]+)"', arrs[1]),
                          temp=int((re.search(r"temp:\s*(\d+)", blk) or [0, 1])[1]) if re.search(r"temp:\s*(\d+)", blk) else 1,
                          hazard=int(re.search(r"hazard:\s*(\d+)", blk).group(1)) if re.search(r"hazard:\s*(\d+)", blk) else 0))

thermal = []
lab_block = lab[lab.index("public static readonly ThermalReaction[] ThermalReactions"):lab.index("public static ThermalReaction MatchThermal")]
for m in re.finditer(r"new ThermalReaction\(", lab_block):
    i = m.start()
    j = lab_block.find("(", i)
    depth = 0
    k = j
    while k < len(lab_block):
        if lab_block[k] == "(":
            depth += 1
        elif lab_block[k] == ")":
            depth -= 1
            if depth == 0:
                break
        k += 1
    blk = lab_block[i:k + 1]
    s = re.findall(r'"([^"]*)"', blk)
    arrs = re.findall(r"new\[\]\s*\{([^}]*)\}", blk)
    thermal.append(dict(id=s[0], inputs=re.findall(r'"([^"]+)"', arrs[0]),
                        outputs=re.findall(r'"([^"]+)"', arrs[1])))

with open(os.path.join(ROOT, "FreeChem", "LootTables", "free_chem_drops.json"), encoding="utf-8-sig") as f:
    loot = json.load(f)
loot_src = {}
for tbl in loot["tables"]:
    tot = sum(e["weight"] for e in tbl["entries"])
    for e in tbl["entries"]:
        loot_src.setdefault(e["id"], []).append("%s %.2f%%" % (tbl["id"].replace("free_chem_", ""), 100.0 * e["weight"] / tot))
for p in loot["patches"]:
    if "table" in p:
        for e in p.get("add", []):
            loot_src.setdefault(e["id"], []).append("%s +%d" % (p["table"], e["weight"]))

starter = block(modentry, "foreach (var id in new[] {", "})")
gasorder = block(modentry, "string[] pack = {", "};")
apparatus = block(modentry, "static readonly string[] ApparatusIds =", "};")
order_pack = block(phone, "public static readonly string[] OrderPack =", "};")
machine_ids = block(recipes, "public static readonly string[] MachineIds =", "};")
vanilla_analog = {}
seg = recipes[recipes.index("VanillaAnalog"):recipes.index("public static string Normalize")]
for m in re.finditer(r'\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\}', seg):
    vanilla_analog[m.group(1)] = m.group(2)
canister_skus = {}
for m in re.finditer(r'\{\s*"(gas_\w+)"\s*,\s*new\[\]\s*\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\}\s*\}', recipes):
    canister_skus[m.group(1)] = [m.group(2), m.group(3), m.group(4)]
drum_skus = {}
for m in re.finditer(r'\{\s*"(gas_\w+)"\s*,\s*"(gas_drum_\w+)"\s*\}', recipes):
    drum_skus[m.group(1)] = m.group(2)

sources = {s["id"]: [] for s in specs}
uses = {s["id"]: [] for s in specs}
for s in specs:
    i = s["id"]
    if i in loot_src:
        sources[i].append("掉落 " + "/".join(loot_src[i]))
    if i in starter:
        sources[i].append("开局礼包")
    if i in gasorder:
        sources[i].append("气体订单")
    if i in apparatus:
        sources[i].append("发明家器材位")
    if i in order_pack:
        sources[i].append("电话$320包")
    if i in machine_ids:
        sources[i].append("发明家机器位")
    if i in ("gas_canister_empty", "sol_sodium_chloride"):
        sources[i].append("发明家直售")
for r in reactions:
    for o in r["outputs"]:
        if o in sources:
            sources[o].append("反应 " + r["id"])
    for x in r["inputs"]:
        if x in uses:
            uses[x].append(r["id"])
for t in thermal:
    for o in t["outputs"]:
        if o in sources:
            sources[o].append("热反应 " + t["id"])
    for x in t["inputs"]:
        if x in uses:
            uses[x].append(t["id"])
for gas, skus in canister_skus.items():
    if skus[0] in sources:
        sources[skus[0]].append("灌装(" + gas + ")")
    for sku in skus[1:]:
        sources.setdefault(sku, []).append("LEGACY_ONLY")
for gas, drum in drum_skus.items():
    if drum in sources:
        sources[drum].append("灌装(" + gas + ")")
for v, m in vanilla_analog.items():
    if m in sources:
        sources[m].append("原版折算")

USES = {
    "thermometer": "点一下切全局温度档(0/1/2/3)",
    "ph_meter": "点一下切全局 pH(1/7/13)",
    "precision_balance": "点一下切全局「配平」",
    "safety_goggles": "点一下切全局「防护」",
    "catalyst_kit": "设备投料槽(催化条件)；打印机充能",
    "label_printer": "盖纯度/品级标签(可造假)",
    "gas_canister_empty": "灌装台空瓶槽→can_*；装气后进气瓶槽",
    "gas_drum_empty": "灌装台空瓶槽→gas_drum_*",
    "alcohol_lamp": "加热台加热器槽；点击切 99/160℃",
    "spirit_burner": "加热台加热器槽；点击切 99/160℃",
    "wick_cotton": "加热台灯芯槽(耐久 20)",
    "wick_ceramic": "加热台灯芯槽(耐久 40)",
    "filter_paper": "过滤台滤纸槽(22μm，耐久 8)",
    "filter_paper_fine": "过滤台滤纸槽(5μm，耐久 5)",
    "filter_paper_ash": "过滤台滤纸槽(2μm，耐久 3)",
    "beaker": "加热台反应槽(只占位，不参与匹配)",
    "retort_flask": "加热台反应槽(只占位)",
    "erlenmeyer_flask": "加热台反应槽(只占位)",
    "test_tube_rack": "加热台反应槽(只占位)",
    "liq_ethanol": "加热台燃料槽(燃料)",
    "sludge": "失败/事故产物(仅可卖)",
    "sol_sediment": "滗析副产物(仅可卖)",
    "note_chem_dealer": "无(已被原版 handnote 取代)",
    "sol_caffeine": "无(产线已删)",
    "sol_coffee_grounds": "无(产线已删)",
}
for k, v in USES.items():
    if k in uses:
        uses[k].append(v)
for sku, gas in [(s2, g) for g, skus in canister_skus.items() for s2 in skus]:
    if sku in uses:
        uses[sku].append("气瓶槽供气→" + gas)

zh = {}
with open(os.path.join(ROOT, "FreeChem", "Localization", "zh.csv"), encoding="utf-8-sig") as f:
    for line in f:
        line = line.rstrip("\n")
        if "," in line and not line.startswith("#"):
            k, v = line.split(",", 1)
            zh[k.strip()] = v

KIND_CN = {"gas": "气体", "liquid": "液体", "solid": "固体", "canister": "钢瓶商品",
           "drum": "大型气桶", "container": "空容器", "tool": "工具/仪器", "protective": "防护",
           "vessel": "器材", "consumable": "耗材", "heater": "加热器", "illicit": "违禁品",
           "byproduct": "副产物"}

# 数字 ID
order = re.findall(r'"([^"]+)"', itemids[itemids.index("public static readonly string[] Ordered"):itemids.index("public static bool TryGetId")])
num = {x: i + 1 for i, x in enumerate(order)}

lines = []
lines.append("| # | 物品 id | 中文名 | 类别 | 价格 | 占格 | 获取途径 | 用途 | 玩家判定 |")
lines.append("|---|---|---|---|---|---|---|---|---|")
for s in specs:
    i = s["id"]
    src = "；".join(dict.fromkeys(x for x in sources[i] if x != "LEGACY_ONLY")) or "**无**"
    use = "；".join(dict.fromkeys([u for u in uses[i] if u not in reactions and u not in thermal][:4]))
    joined = [u for u in uses[i] if u not in reactions and u not in thermal]
    name = zh.get(i + "_name", i)
    if "LEGACY_ONLY" in sources[i]:
        src = "（旧档/调试专用，正常游戏无法获得）"
    if i == "sludge":
        verdict = "副产物：失败/事故产出，只能卖钱"
    elif src == "**无**":
        verdict = "**死物品：没有任何获取途径**"
    elif "LEGACY_ONLY" in sources[i]:
        verdict = "**legacy：产线已停，只存在于旧档/调试**"
    elif not joined:
        verdict = "**无用途：只能卖钱**"
    elif s["kind"] == "byproduct":
        verdict = "副产物：只能卖钱"
    else:
        verdict = "正常"
    if i == "note_chem_dealer":
        verdict = "**死物品（被原版 handnote 取代）**"
    price = "$%d" % s["value"]
    if s["kind"] == "canister":
        bonus = {"Industrial": 0, "Medical": 85, "UltraPure": 135}[s["grade"]]
        price = "$%d(+%d%%)" % (s["value"], bonus) if bonus else "$%d" % s["value"]
    lines.append("| %d | `%s` | %s | %s | %s | %s | %s | %s | %s |"
                 % (num.get(i, 0), i, name, KIND_CN.get(s["kind"], s["kind"]), price,
                    cells.get(i, "?"), src, use if use else "—", verdict))

# 机器表
machines = []
for m in re.finditer(r'case "(\w+)":\s*\n\s*return new MachineLayout \{([^}]*)\}', read("ChemMachines.cs")):
    mid = m.group(1)
    body = m.group(2)
    pw = 0
    pm = re.search(r'case "%s":\s*return (\d+);' % mid, read("ChemMachines.cs"))
    if pm:
        pw = int(pm.group(1))
    ow = re.search(r"OutputW = (\d+)", body)
    oh = re.search(r"OutputH = (\d+)", body)
    ins = re.search(r"InputSlots = (\d+)", body)
    machines.append(dict(id=mid, power=pw,
                         out=(int(ow.group(1)) * int(oh.group(1))) if ow and oh else 9,
                         outw=int(ow.group(1)) if ow else 3, outh=int(oh.group(1)) if oh else 3,
                         ins=int(ins.group(1)) if ins else 2,
                         filter="FilterSlot = true" in body,
                         container="ContainerSlot = true" in body))
machines.append(dict(id="heating_platform", power=0, out=18, outw=6, outh=3, ins=4, filter=False, container=False))

mlines = []
mlines.append("| 设备 id | 中文名 | 价格 | 电力 | 投料槽 | 专用槽 | 产出格 | 夜间配方数 | 热反应数 |")
mlines.append("|---|---|---|---|---|---|---|---|---|")
for m in machines:
    i = m["id"]
    nrec = len([r for r in reactions if r["machine"] == i])
    nth = len([t for t in thermal if i == "heating_platform"])
    special = []
    if m["filter"]:
        special.append("滤纸槽(标成「投料 2」)")
    if m["container"]:
        special.append("空瓶槽(标成「投料 2」)")
    if i != "heating_platform":
        special.append("2 个气瓶槽")
    price = 420 if i == "heating_platform" else 300 + m["power"] * 20
    mlines.append("| `%s` | %s | $%d | %s | %d | %s | %dx%d=%d | %d | %d |"
                  % (i, zh.get(i + "_name", i), price,
                     ("%d" % m["power"]) if m["power"] else "0(不用电)",
                     m["ins"], "；".join(special), m["outw"], m["outh"], m["out"],
                     nrec, nth))

out = "\n".join(lines) + "\n\n<!-- MACHINES -->\n\n" + "\n".join(mlines) + "\n"
with open(os.path.join(ROOT, "tools", "item_table.md"), "w", encoding="utf-8") as f:
    f.write(out)
print("写入 tools/item_table.md，%d 行" % len(out.splitlines()))
print("物品数 =", len(specs), " 机器数 =", len(machines))
